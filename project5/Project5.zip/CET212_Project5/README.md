# CET212 - Operating System 1 | Project 5: Process Scheduling Simulation

A Python simulator that compares CPU scheduling algorithms
(FCFS, SJF, SRTF, Priority NP/P, Round-Robin, MLFQ) with context-switch
overhead, performance metrics and Gantt charts.

## Files
| File | Purpose |
|---|---|
| `scheduler.py` | Process model, ready queue, simulation engine, all algorithms |
| `main.py` | Experiments + command-line interface |
| `visualize.py` | Gantt charts and comparison plots |
| `test_scheduler.py` | Unit tests (textbook results + invariants) |
| `workload_example.csv` | Example input file |
| `results/` | Generated charts, `results.txt`, `results.json` |
| `Project5_Process_Scheduling_Report.docx` | Full report |

## Requirements
Python 3.9+ and matplotlib:  `pip install matplotlib`

## Run
```
python test_scheduler.py                         # run the tests
python main.py                                   # all experiments -> results/
python main.py --input workload_example.csv -q 3 --cs 1
python main.py --random 8 --seed 7 -q 4
```
Options: `-q` Round-Robin quantum (default 4), `--cs` context-switch cost
(default 0), `--out` output folder, `--no-plots`.

CSV format: `pid,arrival,burst,priority` (smaller priority number = higher priority).
