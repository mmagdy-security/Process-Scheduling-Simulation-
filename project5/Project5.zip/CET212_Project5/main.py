"""
main.py - runs the experiments and/or simulates your own workload.

Usage
-----
  python main.py                              full experiment suite  -> results/
  python main.py --input my.csv -q 3 --cs 1   simulate a CSV workload
  python main.py --random 8 --seed 7 -q 4     simulate a random workload

CSV format (header optional):  pid,arrival,burst,priority
"""
import argparse
import csv
import json
import os
import random

from scheduler import (Process, run_all, round_robin, mlfq, fcfs, sjf, srtf,
                       priority_np, priority_p, CS_LABEL, IDLE_LABEL)
import visualize as viz

# --------------------------------------------------------------------------- #
#  Workloads
# --------------------------------------------------------------------------- #
def dataset_A():
    """Small, hand-checkable workload (5 processes, staggered arrivals)."""
    return [Process(1, 0, 10, 3), Process(2, 1, 1, 1), Process(3, 2, 2, 4),
            Process(4, 3, 1, 5), Process(5, 4, 5, 2)]

def dataset_B():
    """Mixed workload: a few long CPU-bound jobs among many short ones."""
    return [Process(1, 0, 12, 4), Process(2, 2, 3, 2), Process(3, 3, 7, 3),
            Process(4, 5, 2, 1), Process(5, 6, 9, 5), Process(6, 9, 4, 2),
            Process(7, 12, 1, 1)]

def dataset_C(n=12, seed=42):
    """Random workload (reproducible with the seed)."""
    return random_workload(n, seed)

def random_workload(n, seed):
    rnd = random.Random(seed)
    # the first process arrives at t=0 so the CPU is never idle at the start
    return [Process(i + 1, 0 if i == 0 else rnd.randint(0, 20), rnd.randint(1, 15),
                    rnd.randint(1, 5)) for i in range(n)]

def load_csv(path):
    procs = []
    with open(path, newline="") as f:
        for row in csv.reader(f):
            if not row or not row[0].strip().lstrip("-").isdigit():
                continue                                  # skip header / blank lines
            v = [int(x) for x in row[:4]]
            procs.append(Process(v[0], v[1], v[2], v[3] if len(v) > 3 else 0))
    return procs

# --------------------------------------------------------------------------- #
#  Text output
# --------------------------------------------------------------------------- #
def gantt_text(result):
    parts = []
    for lab, s, e in result.gantt:
        tag = lab if isinstance(lab, str) else f"P{lab}"
        parts.append(f"|{tag}:{s}-{e}")
    return " ".join(parts) + "|"

def process_table(result):
    lines = [f"  {'PID':<4}{'AT':>4}{'BT':>4}{'Pri':>5}{'CT':>5}{'TAT':>5}{'WT':>5}{'RT':>5}"]
    for p in sorted(result.processes, key=lambda x: x.pid):
        lines.append(f"  P{p.pid:<3}{p.arrival:>4}{p.burst:>4}{p.priority:>5}"
                     f"{p.completion:>5}{p.turnaround:>5}{p.waiting:>5}{p.response:>5}")
    return "\n".join(lines)

def summary_table(results):
    h = (f"{'Algorithm':<22}{'Avg WT':>8}{'Avg TAT':>9}{'Avg RT':>8}"
         f"{'CtxSw':>7}{'CPU%':>8}{'Thr.':>7}")
    rows = [h, "-" * len(h)]
    for r in results:
        rows.append(f"{r.name:<22}{r.avg_waiting:>8.2f}{r.avg_turnaround:>9.2f}"
                    f"{r.avg_response:>8.2f}{r.context_switches:>7}"
                    f"{r.cpu_utilization:>8.1f}{r.throughput:>7.3f}")
    return "\n".join(rows)

def describe(procs):
    return "\n".join(["  PID  AT  BT  Priority"] +
                     [f"  P{p.pid:<3}{p.arrival:>4}{p.burst:>4}{p.priority:>6}" for p in procs])

# --------------------------------------------------------------------------- #
#  Custom workload mode
# --------------------------------------------------------------------------- #
def run_custom(procs, quantum, cs, out, plots):
    os.makedirs(out, exist_ok=True)
    results = run_all(procs, quantum, cs)
    print(f"\nWorkload ({len(procs)} processes), quantum={quantum}, context-switch cost={cs}")
    print(describe(procs))
    for r in results:
        print(f"\n=== {r.name} ===")
        print("Gantt:", gantt_text(r))
        print(process_table(r))
        print(f"  Avg WT = {r.avg_waiting:.2f} | Avg TAT = {r.avg_turnaround:.2f} "
              f"| Context switches = {r.context_switches}")
    print("\n" + summary_table(results))
    if plots:
        viz.gantt_grid(results, f"{out}/custom_gantt.png", "Gantt charts - custom workload")
        viz.comparison_bars(results, f"{out}/custom_comparison.png", "Comparison - custom workload")
        print(f"\nCharts saved in {out}/")

# --------------------------------------------------------------------------- #
#  Full experiment suite (used for the report)
# --------------------------------------------------------------------------- #
def run_experiments(out, plots, quantum=4):
    os.makedirs(out, exist_ok=True)
    report, data = [], {}
    log = lambda s="": (print(s), report.append(s))

    datasets = {"A": dataset_A(), "B": dataset_B(), "C": dataset_C()}

    # ---- 1. all algorithms x all datasets -------------------------------- #
    for key, procs in datasets.items():
        results = run_all(procs, quantum=quantum, cs=0)
        log("=" * 78)
        log(f"DATASET {key}  (quantum = {quantum}, no context-switch cost)")
        log("=" * 78)
        log(describe(procs))
        for r in results:
            log(f"\n--- {r.name} ---")
            log("Gantt: " + gantt_text(r))
            log(process_table(r))
        log("\nSUMMARY\n" + summary_table(results) + "\n")
        data[f"dataset_{key}"] = {
            "processes": [dict(pid=p.pid, arrival=p.arrival, burst=p.burst, priority=p.priority)
                          for p in procs],
            "results": [dict(name=r.name, avg_waiting=r.avg_waiting,
                             avg_turnaround=r.avg_turnaround, avg_response=r.avg_response,
                             context_switches=r.context_switches,
                             cpu_utilization=r.cpu_utilization, throughput=r.throughput,
                             gantt=[[str(l), s, e] for l, s, e in r.gantt],
                             per_process=[dict(pid=p.pid, ct=p.completion, tat=p.turnaround,
                                               wt=p.waiting, rt=p.response)
                                          for p in sorted(r.processes, key=lambda x: x.pid)])
                        for r in results]}
        if plots:
            viz.comparison_bars(results, f"{out}/comparison_{key}.png",
                                f"Dataset {key}: average waiting / turnaround / response time")
            if key in ("A", "B"):
                viz.gantt_grid(results, f"{out}/gantt_{key}.png",
                               f"Gantt charts - Dataset {key}")
                for r in results:
                    safe = r.name.split(" (")[0].replace(" ", "_").lower()
                    if r.name.startswith(("Priority", "Round", "MLFQ")):
                        safe = r.name.replace(" ", "_").replace("(", "").replace(")", "") \
                                     .replace("=", "").replace(",", "-").lower()
                    viz.gantt_single(r, f"{out}/gantt_{key}_{safe}.png")

    # ---- 2. time-quantum analysis (Round-Robin, dataset C) --------------- #
    procs = datasets["C"]
    qs = list(range(1, 16))
    q_wt, q_tat, q_sw, q_tat_cs, q_tat_cs2 = [], [], [], [], []
    for q in qs:
        r0 = round_robin(procs, q, 0)
        q_wt.append(r0.avg_waiting); q_tat.append(r0.avg_turnaround)
        q_sw.append(r0.context_switches)
        q_tat_cs.append(round_robin(procs, q, 1).avg_turnaround)
        q_tat_cs2.append(round_robin(procs, q, 2).avg_turnaround)
    log("=" * 78)
    log("TIME-QUANTUM ANALYSIS - Round-Robin on dataset C")
    log("=" * 78)
    log(f"{'q':>3}{'AvgWT':>9}{'AvgTAT':>9}{'CtxSw':>7}{'TAT(cs=1)':>11}{'TAT(cs=2)':>11}")
    for i, q in enumerate(qs):
        log(f"{q:>3}{q_wt[i]:>9.2f}{q_tat[i]:>9.2f}{q_sw[i]:>7}{q_tat_cs[i]:>11.2f}{q_tat_cs2[i]:>11.2f}")
    log()
    data["quantum_analysis"] = dict(q=qs, avg_wt=q_wt, avg_tat=q_tat, switches=q_sw,
                                    avg_tat_cs1=q_tat_cs, avg_tat_cs2=q_tat_cs2)
    if plots:
        viz.line_plot({"cs = 0": q_tat, "cs = 1": q_tat_cs, "cs = 2": q_tat_cs2}, qs,
                      f"{out}/quantum_tat.png",
                      "Round-Robin: average turnaround time vs. time quantum (dataset C)",
                      "Time quantum", "Average turnaround time")
        viz.line_plot({"Context switches": q_sw}, qs, f"{out}/quantum_switches.png",
                      "Round-Robin: number of context switches vs. time quantum (dataset C)",
                      "Time quantum", "Context switches")

    # ---- 3. context-switch overhead analysis (all algorithms, dataset C) -- #
    css = list(range(0, 6))
    names = [r.name for r in run_all(procs, quantum, 0)]
    tat_by, util_by, wt_by = ({n: [] for n in names} for _ in range(3))
    for c in css:
        for r in run_all(procs, quantum, c):
            tat_by[r.name].append(r.avg_turnaround)
            wt_by[r.name].append(r.avg_waiting)
            util_by[r.name].append(r.cpu_utilization)
    log("=" * 78)
    log("CONTEXT-SWITCH OVERHEAD ANALYSIS - dataset C, quantum = %d" % quantum)
    log("=" * 78)
    log("Average turnaround time:")
    log(f"{'Algorithm':<22}" + "".join(f"{'cs='+str(c):>8}" for c in css))
    for n in names:
        log(f"{n:<22}" + "".join(f"{v:>8.2f}" for v in tat_by[n]))
    log("\nCPU utilization (%):")
    log(f"{'Algorithm':<22}" + "".join(f"{'cs='+str(c):>8}" for c in css))
    for n in names:
        log(f"{n:<22}" + "".join(f"{v:>8.1f}" for v in util_by[n]))
    log()
    data["cs_analysis"] = dict(cs=css, avg_tat=tat_by, avg_wt=wt_by, cpu_util=util_by,
                               switches={r.name: r.context_switches for r in run_all(procs, quantum, 0)})
    if plots:
        viz.line_plot(tat_by, css, f"{out}/cs_tat.png",
                      "Effect of context-switch cost on average turnaround time (dataset C)",
                      "Context-switch cost (time units)", "Average turnaround time")
        viz.line_plot(util_by, css, f"{out}/cs_util.png",
                      "Effect of context-switch cost on CPU utilization (dataset C)",
                      "Context-switch cost (time units)", "CPU utilization (%)")

    # ---- 4. MLFQ configuration study (dataset B) ------------------------- #
    log("=" * 78)
    log("MLFQ CONFIGURATIONS - dataset B")
    log("=" * 78)
    configs = [(2, 4, 8), (1, 2, 4), (4, 8, 16), (2, 4, 8, 16)]
    log(f"{'Config':<16}{'AvgWT':>8}{'AvgTAT':>9}{'AvgRT':>8}{'CtxSw':>7}")
    data["mlfq_configs"] = []
    for cfg in configs:
        r = mlfq(datasets["B"], cfg)
        log(f"{str(cfg):<16}{r.avg_waiting:>8.2f}{r.avg_turnaround:>9.2f}"
            f"{r.avg_response:>8.2f}{r.context_switches:>7}")
        data["mlfq_configs"].append(dict(cfg=list(cfg), wt=r.avg_waiting, tat=r.avg_turnaround,
                                         rt=r.avg_response, sw=r.context_switches))
    log()

    with open(f"{out}/results.txt", "w") as f:
        f.write("\n".join(report))
    with open(f"{out}/results.json", "w") as f:
        json.dump(data, f, indent=1)
    print(f"\nAll results written to {out}/")


def main():
    ap = argparse.ArgumentParser(description="CPU scheduling simulator")
    ap.add_argument("--input", help="CSV file: pid,arrival,burst,priority")
    ap.add_argument("--random", type=int, metavar="N", help="random workload with N processes")
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("-q", "--quantum", type=int, default=4, help="Round-Robin time quantum")
    ap.add_argument("--cs", type=int, default=0, help="context-switch cost (time units)")
    ap.add_argument("--out", default="results", help="output folder")
    ap.add_argument("--no-plots", action="store_true")
    a = ap.parse_args()

    if a.input:
        run_custom(load_csv(a.input), a.quantum, a.cs, a.out, not a.no_plots)
    elif a.random:
        run_custom(random_workload(a.random, a.seed), a.quantum, a.cs, a.out, not a.no_plots)
    else:
        run_experiments(a.out, not a.no_plots, a.quantum)


if __name__ == "__main__":
    main()
