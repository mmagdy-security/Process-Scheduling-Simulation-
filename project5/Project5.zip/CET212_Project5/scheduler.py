"""
scheduler.py
============
Core of the CPU-scheduling simulator.
CET212 - Operating System 1 | Project 5: Process Scheduling Simulation

Implemented algorithms
----------------------
  * FCFS                      (baseline)
  * SJF  non-preemptive       (Shortest Job First)
  * SRTF preemptive           (Shortest Remaining Time First)
  * Priority non-preemptive   (smaller number = higher priority)
  * Priority preemptive
  * Round-Robin               (configurable time quantum)
  * MLFQ                      (Multi-Level Feedback Queue - extension)

Context-switch model
--------------------
A context switch is counted every time the CPU is given to a process that is
different from the one that ran last (no switch is counted after an idle gap or
for the very first dispatch).  If ``cs`` > 0, each switch costs ``cs`` time units
during which no process makes progress (the "CS" block in the Gantt chart).

Conventions
-----------
  Turnaround = Completion - Arrival
  Waiting    = Turnaround - Burst
  Response   = First CPU time - Arrival
Time is measured in integer time units.
"""
from __future__ import annotations

from collections import deque
from dataclasses import dataclass, field
from typing import Callable, Deque, Dict, List, Optional, Sequence, Tuple

CS_LABEL = "CS"
IDLE_LABEL = "IDLE"

# One Gantt-chart block: (pid | "CS" | "IDLE", start, end)
Segment = Tuple[object, int, int]


# --------------------------------------------------------------------------- #
#  Data model
# --------------------------------------------------------------------------- #
@dataclass
class Process:
    """A process (PCB-like record) used by the simulation."""
    pid: int
    arrival: int
    burst: int
    priority: int = 0
    # --- filled in by the simulation ---
    remaining: int = field(default=0, init=False)
    start_time: Optional[int] = field(default=None, init=False)
    completion: int = field(default=0, init=False)

    def __post_init__(self) -> None:
        if self.burst <= 0:
            raise ValueError(f"P{self.pid}: burst time must be > 0")
        if self.arrival < 0:
            raise ValueError(f"P{self.pid}: arrival time must be >= 0")
        self.remaining = self.burst

    def fresh(self) -> "Process":
        """Return an un-simulated copy (so one dataset can be reused)."""
        return Process(self.pid, self.arrival, self.burst, self.priority)

    @property
    def turnaround(self) -> int:
        return self.completion - self.arrival

    @property
    def waiting(self) -> int:
        return self.turnaround - self.burst

    @property
    def response(self) -> int:
        return (self.start_time or 0) - self.arrival


@dataclass
class SimResult:
    """Everything produced by one simulation run."""
    name: str
    processes: List[Process]
    gantt: List[Segment]
    context_switches: int
    cs_time: int

    def _avg(self, fn: Callable[[Process], float]) -> float:
        return sum(fn(p) for p in self.processes) / len(self.processes)

    @property
    def avg_waiting(self) -> float:
        return self._avg(lambda p: p.waiting)

    @property
    def avg_turnaround(self) -> float:
        return self._avg(lambda p: p.turnaround)

    @property
    def avg_response(self) -> float:
        return self._avg(lambda p: p.response)

    @property
    def makespan(self) -> int:
        return max(p.completion for p in self.processes)

    @property
    def cpu_utilization(self) -> float:
        """Useful CPU work / total elapsed time, in percent."""
        return 100.0 * sum(p.burst for p in self.processes) / self.makespan

    @property
    def throughput(self) -> float:
        """Processes completed per time unit."""
        return len(self.processes) / self.makespan


# --------------------------------------------------------------------------- #
#  Helpers
# --------------------------------------------------------------------------- #
def _validate(procs: Sequence[Process]) -> None:
    if not procs:
        raise ValueError("The process list is empty")
    pids = [p.pid for p in procs]
    if len(set(pids)) != len(pids):
        raise ValueError("Process IDs must be unique")


def _add(gantt: List[Segment], label: object, start: int, end: int) -> None:
    """Append a block to the Gantt list, merging it with the previous one if contiguous."""
    if end <= start:
        return
    if gantt and gantt[-1][0] == label and gantt[-1][2] == start:
        gantt[-1] = (label, gantt[-1][1], end)
    else:
        gantt.append((label, start, end))


# --------------------------------------------------------------------------- #
#  Generic engine for FCFS / SJF / SRTF / Priority / Round-Robin
# --------------------------------------------------------------------------- #
def _simulate(
    name: str,
    procs: Sequence[Process],
    select: Callable[[List[Process]], Process],
    *,
    quantum: Optional[int] = None,
    preemptive: bool = False,
    cs: int = 0,
) -> SimResult:
    """
    Event-driven simulation of a single CPU.

    select      : picks the next process from the ready queue.
    quantum     : maximum slice length (Round-Robin); None = no time slicing.
    preemptive  : if True the scheduler is re-run whenever a new process arrives.
    cs          : context-switch overhead (time units).
    """
    _validate(procs)
    ps = [p.fresh() for p in procs]
    pending = sorted(ps, key=lambda p: (p.arrival, p.pid))   # not yet arrived
    n = len(ps)
    ready: List[Process] = []          # the READY QUEUE
    gantt: List[Segment] = []
    time = i = done = switches = cs_time = 0
    last: Optional[int] = None         # pid that used the CPU last

    def admit() -> None:               # move arrived processes into the ready queue
        nonlocal i
        while i < n and pending[i].arrival <= time:
            ready.append(pending[i])
            i += 1

    while done < n:
        admit()
        if not ready:                  # CPU idle until the next arrival
            nxt = pending[i].arrival
            _add(gantt, IDLE_LABEL, time, nxt)
            time, last = nxt, None
            continue

        p = select(ready)
        ready.remove(p)

        # ---- context switch ----
        if last is not None and p.pid != last:
            switches += 1
            if cs:
                _add(gantt, CS_LABEL, time, time + cs)
                time += cs
                cs_time += cs
                admit()                # processes may arrive during the switch

        if p.start_time is None:
            p.start_time = time

        # ---- how long does p run before the scheduler is invoked again? ----
        run = p.remaining
        if quantum is not None:
            run = min(run, quantum)
        if preemptive and i < n:
            run = min(run, pending[i].arrival - time)

        _add(gantt, p.pid, time, time + run)
        time += run
        p.remaining -= run
        last = p.pid
        admit()                        # arrivals during the slice enter BEFORE p re-queues

        if p.remaining == 0:
            p.completion = time
            done += 1
        else:
            ready.append(p)            # back of the ready queue

    return SimResult(name, ps, gantt, switches, cs_time)


# --------------------------------------------------------------------------- #
#  Selection policies
# --------------------------------------------------------------------------- #
def _by_arrival(r: List[Process]) -> Process:
    return min(r, key=lambda p: (p.arrival, p.pid))

def _by_remaining(r: List[Process]) -> Process:
    return min(r, key=lambda p: (p.remaining, p.arrival, p.pid))

def _by_priority(r: List[Process]) -> Process:
    return min(r, key=lambda p: (p.priority, p.arrival, p.pid))

def _head(r: List[Process]) -> Process:
    return r[0]


# --------------------------------------------------------------------------- #
#  Public algorithms
# --------------------------------------------------------------------------- #
def fcfs(procs, cs: int = 0) -> SimResult:
    return _simulate("FCFS", procs, _by_arrival, cs=cs)

def sjf(procs, cs: int = 0) -> SimResult:
    """Shortest Job First (non-preemptive)."""
    return _simulate("SJF", procs, _by_remaining, cs=cs)

def srtf(procs, cs: int = 0) -> SimResult:
    """Shortest Remaining Time First (preemptive SJF)."""
    return _simulate("SRTF", procs, _by_remaining, preemptive=True, cs=cs)

def priority_np(procs, cs: int = 0) -> SimResult:
    """Priority scheduling, non-preemptive (smaller number = higher priority)."""
    return _simulate("Priority (NP)", procs, _by_priority, cs=cs)

def priority_p(procs, cs: int = 0) -> SimResult:
    """Priority scheduling, preemptive."""
    return _simulate("Priority (P)", procs, _by_priority, preemptive=True, cs=cs)

def round_robin(procs, quantum: int = 4, cs: int = 0) -> SimResult:
    if quantum <= 0:
        raise ValueError("quantum must be > 0")
    return _simulate(f"Round-Robin (q={quantum})", procs, _head, quantum=quantum, cs=cs)


# --------------------------------------------------------------------------- #
#  Multi-Level Feedback Queue (extension)
# --------------------------------------------------------------------------- #
def mlfq(procs, quanta: Sequence[int] = (2, 4, 8), cs: int = 0) -> SimResult:
    """
    Multi-Level Feedback Queue.

    * One Round-Robin queue per level; level i has time quantum ``quanta[i]``.
    * New processes enter the TOP queue (level 0).
    * A process that uses its whole quantum is demoted one level
      (it stays in the last level, which keeps running Round-Robin).
    * A higher level always has priority over a lower one: a new arrival
      (which lands in level 0) preempts a process running in a lower level.
      A preempted process keeps its level and the unused part of its quantum.
    This favours short / interactive jobs while long CPU-bound jobs sink down.
    """
    _validate(procs)
    ps = [p.fresh() for p in procs]
    pending = sorted(ps, key=lambda p: (p.arrival, p.pid))
    n = len(ps)
    levels: List[Deque[Process]] = [deque() for _ in quanta]
    slice_left: Dict[int, int] = {}
    gantt: List[Segment] = []
    time = i = done = switches = cs_time = 0
    last: Optional[int] = None

    def admit() -> None:
        nonlocal i
        while i < n and pending[i].arrival <= time:
            p = pending[i]
            slice_left[p.pid] = quanta[0]
            levels[0].append(p)
            i += 1

    while done < n:
        admit()
        k = next((j for j, q in enumerate(levels) if q), None)
        if k is None:
            nxt = pending[i].arrival
            _add(gantt, IDLE_LABEL, time, nxt)
            time, last = nxt, None
            continue

        p = levels[k].popleft()
        if last is not None and p.pid != last:
            switches += 1
            if cs:
                _add(gantt, CS_LABEL, time, time + cs)
                time += cs
                cs_time += cs
                admit()
        if p.start_time is None:
            p.start_time = time

        run = min(p.remaining, slice_left[p.pid])
        if k > 0 and i < n:                       # a new arrival preempts lower levels
            run = min(run, pending[i].arrival - time)

        _add(gantt, p.pid, time, time + run)
        time += run
        p.remaining -= run
        slice_left[p.pid] -= run
        last = p.pid
        admit()

        if p.remaining == 0:
            p.completion = time
            done += 1
        elif slice_left[p.pid] == 0:              # used the full quantum -> demote
            nk = min(k + 1, len(levels) - 1)
            slice_left[p.pid] = quanta[nk]
            levels[nk].append(p)
        else:                                      # preempted by an arrival
            levels[k].appendleft(p)

    name = "MLFQ (" + ",".join(map(str, quanta)) + ")"
    return SimResult(name, ps, gantt, switches, cs_time)


# --------------------------------------------------------------------------- #
#  Convenience
# --------------------------------------------------------------------------- #
def run_all(procs, quantum: int = 4, cs: int = 0,
            mlfq_quanta: Sequence[int] = (2, 4, 8)) -> List[SimResult]:
    """Run every algorithm on the same workload."""
    return [
        fcfs(procs, cs),
        sjf(procs, cs),
        srtf(procs, cs),
        priority_np(procs, cs),
        priority_p(procs, cs),
        round_robin(procs, quantum, cs),
        mlfq(procs, mlfq_quanta, cs),
    ]
