"""
Unit tests - the simulator is checked against textbook results
(Silberschatz, Operating System Concepts) and basic invariants.
Run:  python test_scheduler.py
"""
import random
from scheduler import (Process, fcfs, sjf, srtf, priority_np, priority_p,
                       round_robin, mlfq, run_all, CS_LABEL)

def approx(a, b): return abs(a - b) < 1e-9

def test_sjf_textbook():
    # P1 0/8, P2 1/4, P3 2/9, P4 3/5  -> non-preemptive SJF
    d = [Process(1, 0, 8), Process(2, 1, 4), Process(3, 2, 9), Process(4, 3, 5)]
    r = sjf(d)
    assert [g[0] for g in r.gantt] == [1, 2, 4, 3]
    assert approx(r.avg_waiting, 7.75) and approx(r.avg_turnaround, 14.25)

def test_srtf_textbook():
    d = [Process(1, 0, 8), Process(2, 1, 4), Process(3, 2, 9), Process(4, 3, 5)]
    r = srtf(d)
    assert approx(r.avg_waiting, 6.5)                       # 26 / 4

def test_rr_textbook():
    d = [Process(1, 0, 24), Process(2, 0, 3), Process(3, 0, 3)]
    r = round_robin(d, 4)
    w = {p.pid: p.waiting for p in r.processes}
    assert w == {1: 6, 2: 4, 3: 7} and approx(r.avg_waiting, 17 / 3)

def test_fcfs_textbook():
    d = [Process(1, 0, 24), Process(2, 0, 3), Process(3, 0, 3)]
    assert approx(fcfs(d).avg_waiting, 17.0)                # (0+24+27)/3

def test_priority_textbook():
    # P1 10/p3, P2 1/p1, P3 2/p4, P4 1/p5, P5 5/p2, all arrive at 0 -> avg wait 8.2
    d = [Process(1, 0, 10, 3), Process(2, 0, 1, 1), Process(3, 0, 2, 4),
         Process(4, 0, 1, 5), Process(5, 0, 5, 2)]
    r = priority_np(d)
    assert [g[0] for g in r.gantt] == [2, 5, 1, 3, 4]
    assert approx(r.avg_waiting, 8.2)

def test_idle_gap():
    r = fcfs([Process(1, 5, 3)])
    assert r.gantt[0][0] == "IDLE" and r.processes[0].completion == 8

def test_context_switch_overhead():
    d = [Process(1, 0, 4), Process(2, 0, 4)]
    r0, r1 = round_robin(d, 2, cs=0), round_robin(d, 2, cs=1)
    assert r0.context_switches == r1.context_switches == 3
    assert r1.makespan == r0.makespan + 3
    assert sum(e - s for l, s, e in r1.gantt if l == CS_LABEL) == 3

def test_invariants_random():
    rnd = random.Random(1)
    for _ in range(200):
        n = rnd.randint(1, 9)
        d = [Process(i + 1, rnd.randint(0, 15), rnd.randint(1, 12), rnd.randint(1, 5))
             for i in range(n)]
        cs = rnd.choice([0, 0, 1, 2])
        for r in run_all(d, quantum=rnd.randint(1, 6), cs=cs):
            # 1) every process got exactly its burst time on the CPU
            used = {}
            for lab, s, e in r.gantt:
                if isinstance(lab, int): used[lab] = used.get(lab, 0) + e - s
            assert used == {p.pid: p.burst for p in r.processes}, r.name
            # 2) blocks never overlap and are ordered
            for (_, _, e1), (_, s2, _) in zip(r.gantt, r.gantt[1:]):
                assert e1 <= s2, r.name
            # 3) nothing runs before it arrives; waiting time never negative
            for p in r.processes:
                assert p.start_time >= p.arrival and p.waiting >= 0, r.name
            for lab, s, e in r.gantt:
                if isinstance(lab, int):
                    assert s >= next(p.arrival for p in r.processes if p.pid == lab)

if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for t in tests:
        t(); print(f"[PASS] {t.__name__}")
    print(f"\nAll {len(tests)} tests passed.")
