"""visualize.py - Gantt charts and comparison plots (matplotlib)."""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch

from scheduler import CS_LABEL, IDLE_LABEL

_PALETTE = plt.get_cmap("tab10")


def _color(label):
    if label == CS_LABEL:
        return "#9e9e9e"
    if label == IDLE_LABEL:
        return "#f5f5f5"
    return _PALETTE((int(label) - 1) % 10)


def _draw_gantt(ax, result, title=None, show_xlabel=True):
    for label, s, e in result.gantt:
        hatch = "///" if label == CS_LABEL else None
        ax.barh(0, e - s, left=s, height=0.6, color=_color(label),
                edgecolor="black", linewidth=0.8, hatch=hatch)
        if label not in (CS_LABEL, IDLE_LABEL) and (e - s) >= 1:
            ax.text((s + e) / 2, 0, f"P{label}", ha="center", va="center",
                    fontsize=8, color="white", fontweight="bold")
    ticks = sorted({t for _, s, e in result.gantt for t in (s, e)})
    ax.set_xticks(ticks)
    ax.set_xticklabels(ticks, fontsize=7)
    ax.set_yticks([])
    ax.set_xlim(0, result.gantt[-1][2])
    ax.set_ylim(-0.5, 0.5)
    ax.grid(axis="x", linestyle=":", alpha=0.4)
    if show_xlabel:
        ax.set_xlabel("Time")
    ax.set_title(title or result.name, fontsize=10, loc="left", fontweight="bold")


def _legend(fig, results, has_cs):
    pids = sorted({p.pid for r in results for p in r.processes})
    handles = [Patch(facecolor=_color(p), edgecolor="black", label=f"P{p}") for p in pids]
    if has_cs:
        handles.append(Patch(facecolor="#9e9e9e", edgecolor="black", hatch="///",
                             label="Context switch"))
    fig.legend(handles=handles, loc="lower center", ncol=len(handles), fontsize=8,
               frameon=False)


def gantt_single(result, path):
    fig, ax = plt.subplots(figsize=(10, 1.9))
    _draw_gantt(ax, result)
    _legend(fig, [result], any(l == CS_LABEL for l, _, _ in result.gantt))
    fig.tight_layout(rect=(0, 0.15, 1, 1))
    fig.savefig(path, dpi=160)
    plt.close(fig)


def gantt_grid(results, path, suptitle=None):
    n = len(results)
    fig, axes = plt.subplots(n, 1, figsize=(10, 1.45 * n + 0.8))
    for ax, r in zip(axes, results):
        _draw_gantt(ax, r, show_xlabel=False)
    axes[-1].set_xlabel("Time")
    if suptitle:
        fig.suptitle(suptitle, fontsize=12, fontweight="bold")
    _legend(fig, results, any(l == CS_LABEL for r in results for l, _, _ in r.gantt))
    fig.tight_layout(rect=(0, 0.04, 1, 0.97 if suptitle else 1))
    fig.savefig(path, dpi=140)
    plt.close(fig)


def comparison_bars(results, path, title):
    names = [r.name for r in results]
    wt = [r.avg_waiting for r in results]
    tat = [r.avg_turnaround for r in results]
    rt = [r.avg_response for r in results]
    x = range(len(names))
    w = 0.27
    fig, ax = plt.subplots(figsize=(10, 4.2))
    b1 = ax.bar([i - w for i in x], wt, w, label="Avg waiting time", color="#1f77b4")
    b2 = ax.bar(list(x), tat, w, label="Avg turnaround time", color="#ff7f0e")
    b3 = ax.bar([i + w for i in x], rt, w, label="Avg response time", color="#2ca02c")
    for bars in (b1, b2, b3):
        for b in bars:
            ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.1,
                    f"{b.get_height():.1f}", ha="center", fontsize=7)
    ax.set_xticks(list(x))
    ax.set_xticklabels(names, rotation=20, ha="right", fontsize=8)
    ax.set_ylabel("Time units")
    ax.set_title(title, fontweight="bold")
    ax.legend(fontsize=8)
    ax.grid(axis="y", linestyle=":", alpha=0.5)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)


def line_plot(series, xs, path, title, xlabel, ylabel, markers=True):
    """series: {label: [y values]}"""
    fig, ax = plt.subplots(figsize=(8, 4.2))
    for label, ys in series.items():
        ax.plot(xs, ys, marker="o" if markers else None, markersize=4, label=label)
    ax.set_xlabel(xlabel)
    ax.set_ylabel(ylabel)
    ax.set_title(title, fontweight="bold")
    ax.grid(linestyle=":", alpha=0.6)
    ax.legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(path, dpi=150)
    plt.close(fig)
